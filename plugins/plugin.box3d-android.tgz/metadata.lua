local metadata =
{
    plugin =
    {
        format = "sharedLibrary",
        manifest = {},
    },
}

return metadata
